const getPokemonIndexData = async () => {
  const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=151')
  const data = await response.json()
  return data.results
}

const getDetailedPokemonData = async (pokemonIndex) => {
  const pokemonPromiseArr = pokemonIndex.map(async (pokemon) => {
    const response = await fetch(pokemon.url)
    const data = await response.json()
    return data
  })

  return Promise.all(pokemonPromiseArr)
}

// IIFE: Immediately Invoked Function Expression
(async () => {
  const indexData = await getPokemonIndexData()
  const pokedex = await getDetailedPokemonData(indexData)

  console.log(pokedex);
})()










/* 
  Getting pokemon data
   - get pokemon index data
   - loop over that array and fetch each single pokemon

  Display cards
   - create cards
   - add cards to document
*/

/*
  =============================================
  ==== FIRST SEMI SOLUTION (doesn't work) =====

  const pokemonArr = []

  pokemonIndex.forEach(async (pokemon) => {
    const response = await fetch(pokemon.url)
    const data = await response.json()

    pokemonArr.push(data)
  })
  ===========================================

  =================================================================
  ==== SECOND SOLUTION (NOT EFFICIENT, FETCHES SYNCHRONOUSLY) =====
  
  const pokemonArr = []

  for (const pokemon of pokemonIndex) {
    const response = await fetch(pokemon.url)
    const data = await response.json()

    pokemonArr.push(data)
  }
  =================================================================
*/

  